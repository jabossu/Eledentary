<?php

$smileys = array (

";\-\)"	=>	"winking",
":\-\)"	=>	"smiling",
";\)"	=>	"winking",
":\)"	=>	"smiling",
"=\)"	=>	"smiling",
":\-D"	=>	"grinning",
":\-P"	=>	"tongue_out",
":\-p"	=>	"tongue_out",
":\-\("	=>	"frowning",
":P"	=>	"tongue_out",
":p"	=>	"tongue_out",
":\("	=>	"frowning",
":\-\(\("	=>	"pouting",
":\-/"	=>	"unsure",
":/"	=>	"unsure",
":\-3"	=>	"cute",
":\-O"	=>	"gasping",
"\^\^"	=>	"happy_smiling",
"\^_\^"	=>	"happy_smiling",
"h3art"	=>	"heart",
"X-\("	=>	"irritated",
"o_O"	=>	"surprised",
"O_o"	=>	"surprised_2",
"th\+"	=>	"thumbs_up",
"th\-"	=>	"thumbs_down",

);

