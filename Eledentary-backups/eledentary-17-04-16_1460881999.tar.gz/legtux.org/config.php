<?php

/*
*	DATABASE CONFIG
*/
	$DB_HOST = 'localhost' ;
	$DB_NAME = 'eoolh' ;
	$DB_USER = 'eoolh' ;
	$DB_PASSWORD = '1rtrta1rtft' ;
	
/*
*	Website Config
*/

$listelangues = array ( 
	'Français'	=>	'fr_FR',
	'English'	=>	'en_EN',
	'Romana'	=>	'ro_RO'
	 ) ;


