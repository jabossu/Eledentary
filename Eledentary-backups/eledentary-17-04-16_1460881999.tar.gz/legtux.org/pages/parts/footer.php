<div id='footer'>
<?php

	echo 'copyright : 2015-2016, &copy; <i>Virtual Tree</i>' ;
	echo ' - ' ;
	echo $siteconfig->websiteFooter();

?>
</div>
