<div id='profile'>
<?php

$em = new elevesManager($bdd) ;
$mm = new messagesManager($bdd) ;

display('profile_title', 'h4', substr($_SESSION['profile']->prenom(), 0, 3) . substr($_SESSION['profile']->nom(), 0, 6) ) ;

if ($_SESSION['profile']->statut() == 'administrateur')
{?>
<a href='/?page=eleves&year=0&role=nouveau' class="btn btn-primary btn-block">
<?php $n = $em->nombre('nouveau') ;
	if ( $n > 0)
	{
		echo "<span class='badge'>". $n . "</span>" ;
		display('new_users') ;
	}
	else
	{
		display('no_new_user') ;
	}
?> </a>


<a href="/?page=viewmessages" class="btn btn-primary btn-block"><span class="badge"><?php echo $mm->nombre('nonlu') ; ?></span><?php display('admin_messages') ; ?></a> 
<?php }
?>

<a href='?page=sendmessage' class="btn btn-primary btn-block">
<span class="glyphicon glyphicon-send"></span><?php display('page_contact') ; ?></a>

<a href='/?page=accueil&action=logout' class="btn btn-primary btn-block">
<span class="glyphicon glyphicon-off"></span> <?php display('page_deconnexion') ; ?></a> 

</div>
