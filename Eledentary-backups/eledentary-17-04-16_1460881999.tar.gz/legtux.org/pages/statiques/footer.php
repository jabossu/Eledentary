
<!-- ===================================
				Footer : 
=================================== -->
<div id='footer'>
<?php

	echo 'copyright : 2015, &copy; <u>Corporation Médecine Cluj</u> under <a href="ressources/license-GPL.html">GPL license</a>' ;
	echo ' - ' ;
	display('contributors', 'b', '<i>A. Touati ; J-A. Bossu</i>') ;

?>
</div>
