
<!-- ===================================
			Bannière du site : 
==================================== -->
<div id='banniere'>
	<div class='row'>

	<div class="col-sm-8">
		<h2><?php display('site_name') ;?></h2>
		
		<div class='text-left'><h4><hr/><b>&rsaquo;</b> <?php display('site_title') ;?></h4></div>
	</div>
	
	<div class="col-sm-2 languages text-right">
	<?php

	/*
	=======================================
	listelangues est creee dans /config.php
	=======================================
	$listelangues = array ( 
		'français'	=>	'fr_FR',
		'roumain'	=>	'ro_RO',
		'anglais'	=>	'en_EN'
		 ) ;
	*/

	foreach( $listelangues as $nom => $code )
	{
		if ( $code == $_SESSION['langue'] )
		{
			$selected = 'current_language' ;
		}
		else
		{
			$selected = '' ;
		}
		
		echo "\t<a href='/?langue=". $code ."' title='Traduire en ". $nom ."'><img src='ressources/images/flag-". $code .".jpg' class='img-thumbnail ". $selected ."' alt='Drapeau ". $nom ."' width='60' /></a><br/>" ;
	}

	?>
	</div>
	
	<div class="col-sm-2">
		<a href="http://eoolh.legtux.org"><img class="logo-icon img-circle img-responsive" alt="Le logo de la CMC dentaire" src='ressources/images/logo.png'></a>
	</div>
	
	</div>
</div>


