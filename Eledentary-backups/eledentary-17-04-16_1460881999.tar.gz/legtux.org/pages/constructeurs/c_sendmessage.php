<?php

/*
*	admins 		= 40
*	legitimate	= 35
*	connected	= 30
*	everyone	= 20
*	visitors	= 10
*/


$accesslevel =  30 ;
