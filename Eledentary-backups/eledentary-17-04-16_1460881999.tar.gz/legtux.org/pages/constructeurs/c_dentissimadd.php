<?php

/*
*	admins 		= 40
*	connected	= 30
*	everyone	= 20
*	visitors	= 10
*/


$accesslevel =  40 ;
