<?php

$errorType = 0 ;

$id = 5 ;

$dm = new dentissimoManager($bdd) ;

$d = $dm->get($id);

