<?php

$errorType = 0 ;

$mm = new messagesManager($bdd) ;

$lm = $mm->getListe() ;
