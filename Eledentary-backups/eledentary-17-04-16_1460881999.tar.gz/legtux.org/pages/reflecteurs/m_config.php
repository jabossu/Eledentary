<?php

$c = new siteconfig( array() );
$cm = new siteconfigManager( $bdd ) ;

$c = $cm->get() ;

if ( isset($_POST) )
{
	$d = new siteconfig($_POST);
}
else
{
	$d = new siteconfig( array() );
}

$siteconfig = $cm->merge( $c, $d );
$cm->update($siteconfig);


